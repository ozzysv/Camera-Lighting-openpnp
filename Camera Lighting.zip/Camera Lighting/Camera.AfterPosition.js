/**
 * Turn on Down Camera Lights
 */
 var downCamLights = machine.getActuatorByName("DownCamLights");
downCamLights.actuate(true);